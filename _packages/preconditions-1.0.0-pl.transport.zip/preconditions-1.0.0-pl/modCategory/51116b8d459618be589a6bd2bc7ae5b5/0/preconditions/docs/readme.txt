--------------------
PreConditions
--------------------
Author: Kudashev Serge <kudashevs@gmail.com>
--------------------

PreConditions is MODx Revolution Extra which allow manipulate data with specified tags in templates
before main parser execution (on first OnParseDocument) by using Conditional output modifiers syntax.

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/PreConditions/issues